package com.snhu.sslserver;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}
}

@RestController
class ServerController{
    // Create a RESTFul route using the @RequestMapping method to generate and 
    // return the required information to the secure web browser    
    @RequestMapping("/hash")
    public String myHash() throws NoSuchAlgorithmException{
    	String data = "Andrew Emilio DiStefano";
       // Create an object of the MessageDigest class using the java.security.MessageDigest library
       // and initialize the object with your selection for an appropriate algorithm cipher. 
       MessageDigest md = MessageDigest.getInstance("SHA-256");

       //Passing data to the created MessageDigest Object
       md.update(data.getBytes());
       
       // Use the digest() method of the class to generate a hash value from data string
       byte[] digest = md.digest();      
       System.out.println(digest);  
       
       // Convert the hash value to hex using the bytesToHex function
       StringBuffer hexString = new StringBuffer();
       for (int i = 0;i<digest.length;i++) {
           hexString.append(Integer.toHexString(0xFF & digest[i]));
       }
        return "<p>data: "+data+"<p>" + 
        "Name of Cipher Algorithm Used: " + md.getAlgorithm() + "<p>" + 
        "CheckSum Value: " + hexString.toString();
    }
}

